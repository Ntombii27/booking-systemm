import { useState, useEffect, useCallback } from 'react'

// Get YYYY-MM-DD for date inputs
function getTodayISO() {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

export default function App() {
  const [allResources, setAllResources] = useState([])
  const [selectedResource, setSelectedResource] = useState('')
  const [selectedDate, setSelectedDate] = useState(getTodayISO())
  
  const [availableSlots, setAvailableSlots] = useState([])
  const [chosenTime, setChosenTime] = useState(null)

  const [userName, setUserName] = useState('')
  const [userEmail, setUserEmail] = useState('')
  const [myBookings, setMyBookings] = useState([])

  const [status, setStatus] = useState({ type: '', text: '' })
  const [isLoadingSlots, setIsLoadingSlots] = useState(false)

  // Load all bookings
  const fetchBookings = useCallback(async () => {
    try {
      const res = await fetch('/api/bookings')
      const data = await res.json()
      setMyBookings(data)
    } catch {
      setStatus({ type: 'error', text: 'Cannot reach the server.' })
    }
  }, [])

  // Load slots for current resource + date
  const fetchSlots = useCallback(async () => {
    if (!selectedResource || !selectedDate) return
    setIsLoadingSlots(true)
    try {
      const res = await fetch(
        `/api/slots?resource=${encodeURIComponent(selectedResource)}&date=${selectedDate}`
      )
      const data = await res.json()
      if (!res.ok) {
        setAvailableSlots([])
        setStatus({ type: 'error', text: data.error || 'Failed to load slots' })
      } else {
        setAvailableSlots(data.availableSlots || [])
      }
    } catch {
      setStatus({ type: 'error', text: 'Cannot reach the server.' })
    } finally {
      setIsLoadingSlots(false)
    }
  }, [selectedResource, selectedDate])

  // Initial load
  useEffect(() => {
    fetch('/api/resources')
      .then(res => res.json())
      .then(data => {
        setAllResources(data)
        if (data.length > 0) setSelectedResource(data[0])
      })
      .catch(() => {
        setStatus({ type: 'error', text: 'Cannot reach the server. Is the backend running?' })
      })
    fetchBookings()
  }, [fetchBookings])

  // Refresh slots when resource/date changes
  useEffect(() => {
    setStatus({ type: '', text: '' })
    fetchSlots()
  }, [fetchSlots])

  // Book a slot
  async function handleBookingSubmit(e) {
    e.preventDefault()
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resource: selectedResource,
          date: selectedDate,
          time: chosenTime,
          name: userName,
          email: userEmail,
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        const msg = data.details ? data.details.join(' ') : data.error
        setStatus({ type: 'error', text: msg })
      } else {
        setStatus({ type: 'success', text: `Booked ${selectedResource} on ${selectedDate} at ${chosenTime}.` })
        setChosenTime(null)
        setUserName('')
        setUserEmail('')
      }
    } catch {
      setStatus({ type: 'error', text: 'Cannot reach the server.' })
    }
    fetchSlots()
    fetchBookings()
  }

  // Cancel
  async function handleCancel(id) {
    try {
      await fetch(`/api/bookings/${id}`, { method: 'DELETE' })
      setStatus({ type: 'success', text: 'Booking cancelled.' })
    } catch {
      setStatus({ type: 'error', text: 'Could not cancel the booking.' })
    }
    fetchSlots()
    fetchBookings()
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold text-purple-700">
          Booking & Reservation System
        </h1>

        {status.text && (
          <div className={`mb-4 rounded p-3 ${status.type === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
            {status.text}
          </div>
        )}

        <div className="grid gap-4 rounded-lg bg-white p-4 shadow sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">Resource</label>
            <select value={selectedResource} onChange={e => setSelectedResource(e.target.value)} className="w-full rounded border border-gray-300 p-2">
              {allResources.map(name => <option key={name} value={name}>{name}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">Date</label>
            <input type="date" value={selectedDate} min={getTodayISO()} onChange={e => setSelectedDate(e.target.value)} className="w-full rounded border border-gray-300 p-2" />
          </div>
        </div>

        <div className="mt-6 rounded-lg bg-white p-4 shadow">
          <h2 className="mb-3 text-xl font-semibold">Available time slots</h2>
          {isLoadingSlots && <p className="text-gray-500">Loading...</p>}
          {!isLoadingSlots && availableSlots.length === 0 && <p className="text-gray-500">No slots available.</p>}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {availableSlots.map(time => (
              <button key={time} onClick={() => setChosenTime(time)} className="rounded border border-purple-600 px-3 py-2 font-medium text-purple-700 hover:bg-purple-600 hover:text-white">
                {time}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 rounded-lg bg-white p-4 shadow">
          <h2 className="mb-3 text-xl font-semibold">My reservations</h2>
          {myBookings.length === 0 ? <p className="text-gray-500">No reservations yet.</p> : (
            <ul className="divide-y">
              {myBookings.map(booking => (
                <li key={booking.id} className="flex items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-medium">{booking.resource} · {booking.date} · {booking.time}</p>
                    <p className="text-sm text-gray-500">{booking.name} ({booking.email})</p>
                  </div>
                  <button onClick={() => handleCancel(booking.id)} className="rounded bg-red-600 px-3 py-1 text-sm text-white hover:bg-red-700">Cancel</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {chosenTime && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleBookingSubmit} className="w-full max-w-sm rounded-lg bg-white p-6 shadow-lg">
            <h2 className="mb-1 text-xl font-semibold">Book {chosenTime}</h2>
            <p className="mb-4 text-sm text-gray-500">{selectedResource} on {selectedDate}</p>
            <input required placeholder="Your name" value={userName} onChange={e => setUserName(e.target.value)} className="mb-3 w-full rounded border p-2" />
            <input required type="email" placeholder="Your email" value={userEmail} onChange={e => setUserEmail(e.target.value)} className="mb-4 w-full rounded border p-2" />
            <div className="flex gap-3">
              <button type="submit" className="flex-1 rounded bg-purple-700 py-2 text-white">Confirm</button>
              <button type="button" onClick={() => setChosenTime(null)} className="flex-1 rounded border py-2">Close</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}