const express = require("express");
const cors = require("cors");
const { randomUUID } = require("crypto");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// ---------- Data (in-memory) ----------
const RESOURCES = [
  "Table 1",
  "Table 2",
  "Table 3",
  "Meeting Room A",
  "Meeting Room B",
];

const ALL_SLOTS = [];
for (let h = 9; h < 17; h++) {
  ALL_SLOTS.push(String(h).padStart(2, "0") + ":00");
}

let bookings = [];

// ---------- Helpers ----------
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValidDate(str) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return (
    dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d
  );
}

function todayString() {
  const n = new Date();
  const m = String(n.getMonth() + 1).padStart(2, "0");
  const d = String(n.getDate()).padStart(2, "0");
  return n.getFullYear() + "-" + m + "-" + d;
}

function isPastDate(date) {
  return date < todayString();
}

function isPastSlot(date, time) {
  if (date !== todayString()) return false;
  const now = new Date();
  const [h, min] = time.split(":").map(Number);
  return h * 60 + min <= now.getHours() * 60 + now.getMinutes();
}

function isBooked(resource, date, time) {
  return bookings.some(
    (b) => b.resource === resource && b.date === date && b.time === time
  );
}

// ---------- Routes ----------
app.get("/api/resources", (req, res) => {
  res.json(RESOURCES);
});

app.get("/api/slots", (req, res) => {
  const { resource, date } = req.query;

  if (!resource || !date) {
    return res
      .status(400)
      .json({ error: "Query params 'resource' and 'date' are required." });
  }
  if (!RESOURCES.includes(resource)) {
    return res.status(400).json({ error: "Unknown resource: " + resource });
  }
  if (!isValidDate(date)) {
    return res.status(400).json({ error: "Date must be valid, format YYYY-MM-DD." });
  }
  if (isPastDate(date)) {
    return res.status(400).json({ error: "Cannot view slots for a past date." });
  }

  const available = ALL_SLOTS.filter(
    (time) => !isBooked(resource, date, time) && !isPastSlot(date, time)
  );

  res.json({ resource, date, availableSlots: available });
});

app.post("/api/bookings", (req, res) => {
  const { resource, date, time, name, email } = req.body || {};

  const errors = [];
  if (!resource || !RESOURCES.includes(resource)) errors.push("A valid resource is required.");
  if (!date || !isValidDate(date)) errors.push("Date must be valid, format YYYY-MM-DD.");
  else if (isPastDate(date)) errors.push("Cannot book a past date.");
  if (!time || !ALL_SLOTS.includes(time)) errors.push("Time must be one of: " + ALL_SLOTS.join(", "));
  else if (date && isValidDate(date) && isPastSlot(date, time)) errors.push("That time has already passed.");
  if (!name || typeof name !== "string" || !name.trim()) errors.push("Name is required.");
  if (!email || !EMAIL_RE.test(email)) errors.push("A valid email is required.");

  if (errors.length) {
    return res.status(400).json({ error: "Validation failed.", details: errors });
  }

  if (isBooked(resource, date, time)) {
    return res.status(409).json({
      error: resource + " is already booked on " + date + " at " + time + ".",
    });
  }

  const booking = {
    id: randomUUID(),
    resource,
    date,
    time,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    createdAt: new Date().toISOString(),
  };
  bookings.push(booking);

  res.status(201).json(booking);
});

app.get("/api/bookings", (req, res) => {
  const sorted = [...bookings].sort((a, b) =>
    (a.date + " " + a.time).localeCompare(b.date + " " + b.time)
  );
  res.json(sorted);
});

app.get("/api/bookings/:date/:resource", (req, res) => {
  const { date, resource } = req.params;

  if (!isValidDate(date)) {
    return res.status(400).json({ error: "Date must be valid, format YYYY-MM-DD." });
  }
  if (!RESOURCES.includes(resource)) {
    return res.status(400).json({ error: "Unknown resource: " + resource });
  }

  const result = bookings
    .filter((b) => b.date === date && b.resource === resource)
    .sort((a, b) => a.time.localeCompare(b.time));

  res.json(result);
});

app.delete("/api/bookings/:id", (req, res) => {
  const index = bookings.findIndex((b) => b.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Booking not found." });
  }
  const removed = bookings.splice(index, 1)[0];
  res.json({ message: "Booking cancelled.", booking: removed });
});

app.use((req, res) => res.status(404).json({ error: "Route not found." }));

app.listen(PORT, () => console.log("API running on http://localhost:" + PORT));