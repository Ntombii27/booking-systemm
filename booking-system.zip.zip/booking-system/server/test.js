const API_BASE = "http://localhost:5000/api";

// Build tomorrow's date as YYYY-MM-DD
function getTomorrowDate() {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const year = tomorrow.getFullYear();
  const month = String(tomorrow.getMonth() + 1).padStart(2, "0");
  const day = String(tomorrow.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const testDate = getTomorrowDate();

// Helper to call API and log nicely
async function testStep(label, path, options) {
  try {
    const response = await fetch(API_BASE + path, options);
    const data = await response.json();
    
    console.log(`\n${label} -> status ${response.status}`);
    console.log(JSON.stringify(data, null, 2));
    return data;
  } catch (err) {
    console.log(`\n${label} -> FAILED to reach server`);
    throw err;
  }
}

async function runTests() {
  const newBooking = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      resource: "Table 1",
      date: testDate,
      time: "10:00",
      name: "Ntombi",
      email: "n@test.com",
    }),
  };

  console.log(`Testing with date: ${testDate}`);

  await testStep("1. Get Resources (expect 200)", "/resources");
  await testStep("2. Get Slots (expect 200)", `/slots?resource=Table%201&date=${testDate}`);
  
  const booking = await testStep("3. Create Booking (expect 201)", "/bookings", newBooking);
  await testStep("4. Duplicate Booking - Conflict (expect 409)", "/bookings", newBooking);
  
  await testStep("5. List Bookings for day (expect 200)", `/bookings/${testDate}/Table%201`);
  await testStep("6. Cancel Booking (expect 200)", `/bookings/${booking.id}`, { method: "DELETE" });
  await testStep("7. Cancel Again - Not Found (expect 404)", `/bookings/${booking.id}`, { method: "DELETE" });

  console.log("\nAll tests done.");
}

runTests().catch(() => {
  console.log("Cannot reach the server. Make sure to start it first with npm start.");
});